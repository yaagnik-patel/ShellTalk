import Conf from 'conf';

const config = new Conf({ projectName: 'shelltalk' });

export function setSession(session) {
  config.set('session', session);
}

export function getSession() {
  return config.get('session');
}

export function clearSession() {
  config.delete('session');
}
