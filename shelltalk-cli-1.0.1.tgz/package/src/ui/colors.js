import chalk from 'chalk';

export const colors = {
  primary: chalk.hex('#10B981'), // Green
  secondary: chalk.hex('#6B7280'), // Gray
  warning: chalk.hex('#F59E0B'), // Yellow
  error: chalk.hex('#EF4444'), // Red
  text: chalk.hex('#E5E7EB'), // Light Gray
  highlight: chalk.hex('#3B82F6'), // Blue
  username: chalk.hex('#8B5CF6'), // Purple
};

export const symbols = {
  online: colors.primary('●'),
  offline: colors.secondary('○'),
  sent: colors.secondary('✓'),
  delivered: colors.warning('✓✓'),
  read: colors.primary('✓✓'),
};
