import crypto from 'crypto';

const ALGORITHM = 'aes-256-gcm';
const HASH_ALGORITHM = 'sha256';
const IV_LENGTH = 12; // GCM recommended IV size
const AUTH_TAG_LENGTH = 16;

// Fallback MVP key for demo, but production should use env
const FALLBACK_KEY = 'SHELLTALK_MVP_FALLBACK_SEC_KEY_0'; 
const ENV_KEY = process.env.SHELLTALK_ENCRYPTION_KEY || FALLBACK_KEY;

// Ensure key is exactly 32 bytes for AES-256
const ENCRYPTION_KEY = crypto.createHash('sha256').update(ENV_KEY).digest();

export function encryptText(plainText) {
  if (!plainText) return null;
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv(ALGORITHM, ENCRYPTION_KEY, iv);
  
  let encrypted = cipher.update(plainText, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  
  const authTag = cipher.getAuthTag().toString('hex');
  
  // Format: iv:authTag:encryptedText
  return `${iv.toString('hex')}:${authTag}:${encrypted}`;
}

export function decryptText(cipherText) {
  if (!cipherText) return null;
  try {
    const parts = cipherText.split(':');
    if (parts.length !== 3) throw new Error('Invalid cipher format');
    
    const iv = Buffer.from(parts[0], 'hex');
    const authTag = Buffer.from(parts[1], 'hex');
    const encrypted = parts[2];
    
    const decipher = crypto.createDecipheriv(ALGORITHM, ENCRYPTION_KEY, iv);
    decipher.setAuthTag(authTag);
    
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return decrypted;
  } catch (error) {
    return '[Unable to decrypt message]';
  }
}

export function hashText(text) {
  if (!text) return null;
  return crypto.createHash(HASH_ALGORITHM).update(text).digest('hex');
}
