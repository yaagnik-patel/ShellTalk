import readline from 'readline';
import chalk from 'chalk';
import { getUser, logout } from '../services/authService.js';
import { getProfile, findProfileByUsernameOrPhone } from '../services/profileService.js';
import { 
  getFriendsWithStats, sendFriendRequest, listIncomingRequests, 
  listOutgoingPendingRequests, acceptFriendRequest, rejectFriendRequest,
  blockUser, unblockUser, checkBlockStatus, areFriends
} from '../services/friendService.js';
import { getChatMessages, sendMessage, markMessagesAsRead, updateMessageStatus, markAllReceivedAsDelivered } from '../services/messageService.js';
import { subscribeToMessages } from '../services/realtimeService.js';
import { renderWelcome, formatMessage } from '../ui/render.js';
import { symbols, colors } from '../ui/colors.js';

// Simple ANSI stripper
function stripAnsi(string) {
  return string.replace(/\x1B\[[0-9;]*[a-zA-Z]/g, '');
}

export async function startShell() {
  const user = await getUser().catch(() => null);
  if (!user) {
    console.log(colors.error('Please login first using `shelltalk login`'));
    process.exit(1);
  }

  let profile;
  try {
    profile = await getProfile(user.id);
  } catch (error) {
    console.log(colors.error('Error fetching profile: ' + error.message));
    process.exit(1);
  }

  if (!profile || !profile.username) {
    console.log(colors.warning('Please setup your profile first using `shelltalk setup`'));
    process.exit(1);
  }

  renderWelcome();

  let currentChatUser = null;
  let friendsCache = [];

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: colors.primary('ShellTalk $ ')
  });

  function updatePrompt() {
    if (currentChatUser) {
      rl.setPrompt(colors.primary(`ShellTalk/@${currentChatUser.username} $ `));
    } else {
      rl.setPrompt(colors.primary('ShellTalk $ '));
    }
    rl.prompt(true);
  }

  const unsubscribe = subscribeToMessages(user.id, {
    onNewMessage: async (msg) => {
      if (currentChatUser && msg.sender_id === currentChatUser.id) {
        // If we are currently in this chat, mark as read immediately
        await markMessagesAsRead(currentChatUser.id, user.id);
        msg.status = 'read';
        process.stdout.write('\n');
        console.log(formatMessage(msg, false, currentChatUser.username));
        updatePrompt();
      } else {
        // If we are not in this chat, just mark as delivered
        await updateMessageStatus(msg.id, 'delivered');
        const friend = friendsCache.find(f => f.id === msg.sender_id);
        const username = friend ? friend.username : 'Unknown';
        process.stdout.write('\n');
        console.log(colors.warning(`🔔 New message from @${username}`));
        updatePrompt();
      }
    },
    onMessageUpdate: (msg) => {
      if (currentChatUser && msg.receiver_id === currentChatUser.id) {
        if (msg.status === 'read') {
          process.stdout.write('\n');
          console.log(colors.primary(`✓✓ @${currentChatUser.username} read your messages.`));
          updatePrompt();
        } else if (msg.status === 'delivered') {
          process.stdout.write('\n');
          console.log(colors.warning(`✓✓ @${currentChatUser.username} received your message.`));
          updatePrompt();
        }
      }
    }
  });

  try {
    friendsCache = await getFriendsWithStats(user.id);
    await markAllReceivedAsDelivered(user.id);
  } catch (e) {
    console.log(colors.error('Failed to load friends or update delivery statuses.'));
  }

  updatePrompt();

  rl.on('line', async (line) => {
    const input = line.trim();
    if (!input) {
      updatePrompt();
      return;
    }

    if (input === 'exit' || input === 'logout') {
      if (input === 'logout') await logout();
      unsubscribe();
      process.exit(0);
    }
    else if (input === 'clear') {
      console.clear();
      renderWelcome();
    }
    else if (input === 'ls') {
      try {
        friendsCache = await getFriendsWithStats(user.id);
        console.log(chalk.bold('\nFriends'));
        if (friendsCache.length === 0) {
          console.log(colors.secondary('No friends yet. Add one with `add <username/phone>`'));
        } else {
          friendsCache.forEach(f => {
            const statusIcon = f.online ? symbols.online : symbols.offline;
            const unreadStr = f.unreadCount > 0 ? colors.primary(`${f.unreadCount} unread`) : colors.secondary('no unread');
            const lastStr = f.lastMessagePreview ? `last: ${f.lastMessagePreview.substring(0, 20)}` : '';
            console.log(`  ${statusIcon} @${f.username.padEnd(12)} ${unreadStr.padEnd(20)} ${colors.secondary(lastStr)}`);
          });
        }
        console.log();
      } catch (e) {
        console.error(colors.error('Failed to load friends: ' + e.message));
      }
    }
    else if (input === 'requests') {
      try {
        const reqs = await listIncomingRequests(user.id);
        console.log(chalk.bold('\nPending Requests'));
        if (reqs.length === 0) {
          console.log(colors.secondary('No pending requests.'));
        } else {
          reqs.forEach((r, idx) => {
            console.log(`  ${idx + 1}. @${r.username}`);
          });
          console.log(colors.secondary('\nUse `accept @username` or `reject @username`'));
        }
        console.log();
      } catch (e) {
        console.error(colors.error('Failed to list requests: ' + e.message));
      }
    }
    else if (input === 'pending') {
      try {
        const reqs = await listOutgoingPendingRequests(user.id);
        console.log(chalk.bold('\nWaiting for acceptance'));
        if (reqs.length === 0) {
          console.log(colors.secondary('No outgoing requests.'));
        } else {
          reqs.forEach(r => {
            console.log(`  @${r.username.padEnd(10)} pending`);
          });
        }
        console.log();
      } catch (e) {
        console.error(colors.error('Failed to list pending: ' + e.message));
      }
    }
    else if (input.startsWith('add ')) {
      const identifier = input.split(' ')[1];
      if (identifier) {
        try {
          const friendProfile = await findProfileByUsernameOrPhone(identifier);
          if (!friendProfile) {
            console.log(colors.warning(`User ${identifier} not found.`));
          } else if (friendProfile.id === user.id) {
            console.log(colors.warning(`You cannot send a friend request to yourself.`));
          } else {
            const isFriend = await areFriends(user.id, friendProfile.id);
            if (isFriend) {
               console.log(colors.warning(`You are already friends with @${friendProfile.username}.`));
            } else {
               const blocked = await checkBlockStatus(user.id, friendProfile.id);
               if (blocked) {
                  console.log(colors.warning(`Cannot send request. User is blocked or has blocked you.`));
               } else {
                  await sendFriendRequest(user.id, friendProfile.id);
                  console.log(colors.primary(`Friend request sent to @${friendProfile.username}. Wait until they accept.`));
               }
            }
          }
        } catch (e) {
          console.error(colors.error(e.message));
        }
      }
    }
    else if (input.startsWith('accept ')) {
      const username = input.split(' ')[1]?.replace('@', '').toLowerCase();
      try {
        const reqs = await listIncomingRequests(user.id);
        const req = reqs.find(r => r.username === username);
        if (!req) {
          console.log(colors.warning(`No pending request found from @${username}.`));
        } else {
          await acceptFriendRequest(req.requestId);
          console.log(colors.primary(`You are now friends with @${username}.`));
          friendsCache = await getFriendsWithStats(user.id);
        }
      } catch (e) {
        console.error(colors.error('Failed to accept: ' + e.message));
      }
    }
    else if (input.startsWith('reject ')) {
      const username = input.split(' ')[1]?.replace('@', '').toLowerCase();
      try {
        const reqs = await listIncomingRequests(user.id);
        const req = reqs.find(r => r.username === username);
        if (!req) {
          console.log(colors.warning(`No pending request found from @${username}.`));
        } else {
          await rejectFriendRequest(req.requestId);
          console.log(colors.primary(`Friend request rejected.`));
        }
      } catch (e) {
        console.error(colors.error('Failed to reject: ' + e.message));
      }
    }
    else if (input.startsWith('block ')) {
      const identifier = input.split(' ')[1];
      try {
        const target = await findProfileByUsernameOrPhone(identifier);
        if (!target) {
          console.log(colors.warning(`User ${identifier} not found.`));
        } else {
          await blockUser(user.id, target.id);
          console.log(colors.primary(`Blocked @${target.username}.`));
        }
      } catch (e) {
        console.error(colors.error('Failed to block: ' + e.message));
      }
    }
    else if (input.startsWith('unblock ')) {
      const identifier = input.split(' ')[1];
      try {
        const target = await findProfileByUsernameOrPhone(identifier);
        if (!target) {
          console.log(colors.warning(`User ${identifier} not found.`));
        } else {
          await unblockUser(user.id, target.id);
          console.log(colors.primary(`Unblocked @${target.username}.`));
        }
      } catch (e) {
        console.error(colors.error('Failed to unblock: ' + e.message));
      }
    }
    else if (input.startsWith('cd ')) {
      const target = input.substring(3).trim();
      if (target === '..') {
        currentChatUser = null;
      } else {
        const username = target.startsWith('@') ? target.substring(1) : target;
        friendsCache = await getFriendsWithStats(user.id);
        const friend = friendsCache.find(f => f.username === username);
        if (friend) {
          currentChatUser = friend;
          await markMessagesAsRead(friend.id, user.id);
          const messages = await getChatMessages(user.id, friend.id);
          console.log();
          messages.forEach(m => {
            console.log(formatMessage(m, m.sender_id === user.id, m.sender_id === user.id ? profile.username : friend.username));
          });
          console.log();
        } else {
          // Check if pending or not friend
          const targetProf = await findProfileByUsernameOrPhone(target);
          if (!targetProf) {
            console.log(colors.warning(`User ${target} not found.`));
          } else {
            console.log(colors.warning(`You are not friends with @${targetProf.username} yet. Send request using \`add @${targetProf.username}\`.`));
          }
        }
      }
    }
    else if (input === 'me') {
       console.log(chalk.bold(`\n@${profile.username}`));
       console.log(`Name: ${profile.display_name}`);
       console.log(`Email: ${profile.email}\n`);
    }
    else {
      // Sending a message or invalid command
      if (currentChatUser) {
        let msgBody = stripAnsi(input);
        if (msgBody.length > 1000) msgBody = msgBody.substring(0, 1000);
        
        try {
          const sent = await sendMessage(user.id, currentChatUser.id, msgBody, currentChatUser.username);
          process.stdout.moveCursor(0, -1);
          process.stdout.clearLine(1);
          console.log(formatMessage(sent, true, profile.username));
        } catch (e) {
          console.log(colors.error('Failed to send: ' + e.message));
        }
      } else {
        console.log(colors.warning(`Unknown command: ${input}`));
        console.log(colors.secondary('Available commands: ls, add, requests, accept, reject, pending, cd, block, unblock, me, clear, exit'));
      }
    }
    updatePrompt();
  });
}
