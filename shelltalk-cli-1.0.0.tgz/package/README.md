# ShellTalk

ShellTalk is a terminal-based messaging app for developers. It feels like Claude Code inside the terminal.

## Setup

1. Create a Supabase project.
2. Run the SQL schema from `supabase/schema.sql` in your Supabase SQL editor.
3. Configure your `.env` file based on `.env.example`.
4. Run `npm install` and `npm link` to install globally.

## Usage

- `shelltalk login` - Login with email OTP.
- `shelltalk setup` - Setup profile (username, display name, phone).
- `shelltalk` - Open the interactive shell.
