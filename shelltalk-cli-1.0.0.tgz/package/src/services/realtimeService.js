import { supabase } from '../config/supabase.js';

export function subscribeToMessages(userId, callbacks) {
  const { onNewMessage, onMessageUpdate } = callbacks;

  const channel = supabase.channel('messages_channel')
    .on(
      'postgres_changes',
      { event: 'INSERT', schema: 'public', table: 'messages', filter: `receiver_id=eq.${userId}` },
      (payload) => {
        if (onNewMessage) onNewMessage(payload.new);
      }
    )
    .on(
      'postgres_changes',
      { event: 'UPDATE', schema: 'public', table: 'messages', filter: `sender_id=eq.${userId}` },
      (payload) => {
        if (onMessageUpdate) onMessageUpdate(payload.new);
      }
    )
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
}
