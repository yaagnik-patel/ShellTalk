import inquirer from 'inquirer';
import ora from 'ora';
import chalk from 'chalk';
import { loginWithOtp, verifyOtp } from '../services/authService.js';

export async function login() {
  const { email } = await inquirer.prompt([
    { type: 'input', name: 'email', message: 'Enter your email:' }
  ]);

  let otpSent = false;

  while (true) {
    if (!otpSent) {
      const spinner = ora('Sending OTP...').start();
      try {
        await loginWithOtp(email);
        spinner.succeed('OTP sent to your email.');
        otpSent = true;
      } catch (error) {
        spinner.fail(chalk.red('Failed to send OTP: ' + error.message));
        return;
      }
    }

    const { token } = await inquirer.prompt([
      { type: 'input', name: 'token', message: 'Enter the OTP (or type "resend" to send a new code):' }
    ]);

    if (token.trim().toLowerCase() === 'resend') {
      otpSent = false;
      continue;
    }

    const spinner2 = ora('Verifying OTP...').start();
    try {
      await verifyOtp(email, token.trim());
      spinner2.succeed('Logged in successfully!');
      break;
    } catch (error) {
      spinner2.fail(chalk.red('Login failed: ' + error.message));
      console.log(chalk.yellow('Please try again or type "resend" if the OTP expired.'));
    }
  }
}
