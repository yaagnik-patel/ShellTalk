import { supabase } from '../config/supabase.js';

export async function addFriend(userId, friendId) {
  const { error } = await supabase
    .from('friends')
    .insert({ user_id: userId, friend_id: friendId });
  if (error) {
    if (error.code === '23505') return; // already friends
    throw error;
  }
}

export async function getFriends(userId) {
  const { data, error } = await supabase
    .from('friends')
    .select(`
      friend_id,
      profiles!friends_friend_id_fkey ( username, display_name, phone )
    `)
    .eq('user_id', userId);
  
  if (error) throw error;
  return data.map(f => ({
    id: f.friend_id,
    username: f.profiles.username,
    displayName: f.profiles.display_name,
    phone: f.profiles.phone
  }));
}

export async function getFriendsWithStats(userId) {
  const friends = await getFriends(userId);
  
  for (let friend of friends) {
    const { count: unreadCount } = await supabase
      .from('messages')
      .select('*', { count: 'exact', head: true })
      .eq('sender_id', friend.id)
      .eq('receiver_id', userId)
      .neq('status', 'read');
    
    friend.unreadCount = unreadCount || 0;

    const { data: lastMsgs } = await supabase
      .from('messages')
      .select('body, created_at')
      .or(`and(sender_id.eq.${userId},receiver_id.eq.${friend.id}),and(sender_id.eq.${friend.id},receiver_id.eq.${userId})`)
      .order('created_at', { ascending: false })
      .limit(1);
    
    friend.lastMessage = lastMsgs && lastMsgs.length > 0 ? lastMsgs[0].body : null;
    friend.online = false; // We can integrate presence later
  }
  return friends;
}
