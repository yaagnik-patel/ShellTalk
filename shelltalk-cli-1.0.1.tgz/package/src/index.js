#!/usr/bin/env node

import { program } from 'commander';
import { login } from './commands/login.js';
import { setup } from './commands/setup.js';
import { startShell } from './commands/shell.js';
import { logout } from './services/authService.js';
import chalk from 'chalk';

program
  .name('shelltalk')
  .description('Terminal-based messaging app for developers')
  .version('1.0.0');

program
  .command('login')
  .description('Login with email OTP')
  .action(login);

program
  .command('setup')
  .description('Setup profile (username, display name, phone)')
  .action(setup);

program
  .command('logout')
  .description('Logout of your account')
  .action(async () => {
    try {
      await logout();
      console.log(chalk.green('Logged out successfully.'));
      process.exit(0);
    } catch (e) {
      console.error(chalk.red('Error logging out: ' + e.message));
      process.exit(1);
    }
  });

program
  .action(() => {
    startShell();
  });

program.parse();
