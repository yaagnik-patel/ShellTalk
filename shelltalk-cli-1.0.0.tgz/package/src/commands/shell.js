import readline from 'readline';
import chalk from 'chalk';
import { getUser, logout } from '../services/authService.js';
import { getProfile, findProfileByUsernameOrPhone } from '../services/profileService.js';
import { getFriendsWithStats, addFriend } from '../services/friendService.js';
import { getChatMessages, sendMessage, markMessagesAsRead } from '../services/messageService.js';
import { subscribeToMessages } from '../services/realtimeService.js';
import { renderWelcome, formatMessage } from '../ui/render.js';
import { symbols, colors } from '../ui/colors.js';

export async function startShell() {
  const user = await getUser().catch(() => null);
  if (!user) {
    console.log(colors.error('Please login first using `shelltalk login`'));
    process.exit(1);
  }

  let profile;
  try {
    profile = await getProfile(user.id);
  } catch (error) {
    console.log(colors.error('Error fetching profile: ' + error.message));
    process.exit(1);
  }

  if (!profile || !profile.username) {
    console.log(colors.warning('Please setup your profile first using `shelltalk setup`'));
    process.exit(1);
  }

  renderWelcome();

  let currentChatUser = null;
  let friendsCache = [];

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: colors.primary('ShellTalk $ ')
  });

  function updatePrompt() {
    if (currentChatUser) {
      rl.setPrompt(colors.primary(`ShellTalk/@${currentChatUser.username} $ `));
    } else {
      rl.setPrompt(colors.primary('ShellTalk $ '));
    }
    rl.prompt(true);
  }

  const unsubscribe = subscribeToMessages(user.id, {
    onNewMessage: async (msg) => {
      if (currentChatUser && msg.sender_id === currentChatUser.id) {
        await markMessagesAsRead(currentChatUser.id, user.id);
        msg.status = 'read';
        process.stdout.write('\n');
        console.log(formatMessage(msg, false, currentChatUser.username));
        updatePrompt();
      } else {
        const friend = friendsCache.find(f => f.id === msg.sender_id);
        const username = friend ? friend.username : 'Unknown';
        process.stdout.write('\n');
        console.log(colors.warning(`🔔 New message from @${username}`));
        updatePrompt();
      }
    },
    onMessageUpdate: (msg) => {
      if (currentChatUser && msg.receiver_id === currentChatUser.id && msg.status === 'read') {
        process.stdout.write('\n');
        console.log(colors.primary(`✓✓ @${currentChatUser.username} read your messages.`));
        updatePrompt();
      }
    }
  });

  try {
    friendsCache = await getFriendsWithStats(user.id);
  } catch (e) {
    console.log(colors.error('Failed to load friends.'));
  }

  updatePrompt();

  rl.on('line', async (line) => {
    const input = line.trim();
    if (!input) {
      updatePrompt();
      return;
    }

    if (input === 'exit' || input === 'logout') {
      if (input === 'logout') await logout();
      unsubscribe();
      process.exit(0);
    }
    else if (input === 'clear') {
      console.clear();
      renderWelcome();
    }
    else if (input === 'ls') {
      try {
        friendsCache = await getFriendsWithStats(user.id);
        console.log(chalk.bold('\nFriends'));
        if (friendsCache.length === 0) {
          console.log(colors.secondary('No friends yet. Add one with `add <username/phone>`'));
        } else {
          friendsCache.forEach(f => {
            const statusIcon = f.online ? symbols.online : symbols.offline;
            const unreadStr = f.unreadCount > 0 ? colors.primary(`${f.unreadCount} unread`) : colors.secondary('no unread');
            const lastStr = f.lastMessage ? `last: ${f.lastMessage.substring(0, 20)}` : '';
            console.log(`  ${statusIcon} @${f.username.padEnd(12)} ${unreadStr.padEnd(20)} ${colors.secondary(lastStr)}`);
          });
        }
        console.log();
      } catch (e) {
        console.error(colors.error('Failed to load friends: ' + e.message));
      }
    }
    else if (input.startsWith('add ')) {
      const identifier = input.split(' ')[1];
      if (identifier) {
        try {
          const friendProfile = await findProfileByUsernameOrPhone(identifier);
          if (!friendProfile) {
            console.log(colors.warning(`User ${identifier} not found.`));
          } else if (friendProfile.id === user.id) {
            console.log(colors.warning(`You cannot add yourself.`));
          } else {
            await addFriend(user.id, friendProfile.id);
            console.log(colors.primary(`Added @${friendProfile.username} as a friend.`));
            friendsCache = await getFriendsWithStats(user.id);
          }
        } catch (e) {
          console.error(colors.error('Error adding friend: ' + e.message));
        }
      }
    }
    else if (input.startsWith('cd ')) {
      const target = input.substring(3).trim();
      if (target === '..') {
        currentChatUser = null;
      } else {
        const username = target.startsWith('@') ? target.substring(1) : target;
        const friend = friendsCache.find(f => f.username === username);
        if (friend) {
          currentChatUser = friend;
          await markMessagesAsRead(friend.id, user.id);
          const messages = await getChatMessages(user.id, friend.id);
          console.log();
          messages.forEach(m => {
            console.log(formatMessage(m, m.sender_id === user.id, friend.username));
          });
          console.log();
        } else {
          console.log(colors.warning(`Friend @${username} not found. Use 'ls' to see friends.`));
        }
      }
    }
    else if (input === 'inbox' || input === 'me') {
      console.log(colors.secondary(`Command '${input}' not fully implemented yet.`));
    }
    else {
      if (currentChatUser) {
        try {
          const msg = await sendMessage(user.id, currentChatUser.id, input);
          console.log(formatMessage(msg, true));
        } catch (e) {
          console.error(colors.error('Failed to send: ' + e.message));
        }
      } else {
        console.log(colors.warning('You are not in a chat. Use `cd @username` to enter a chat or `ls` to list friends.'));
      }
    }

    updatePrompt();
  });
}
