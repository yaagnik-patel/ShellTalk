import inquirer from 'inquirer';
import ora from 'ora';
import chalk from 'chalk';
import { getUser } from '../services/authService.js';
import { getProfile, upsertProfile } from '../services/profileService.js';

export async function setup() {
  try {
    const user = await getUser();
    if (!user) {
      console.log(chalk.red('Please login first using `shelltalk login`'));
      return;
    }

    const currentProfile = await getProfile(user.id) || {};

    const answers = await inquirer.prompt([
      { type: 'input', name: 'displayName', message: 'Display Name:', default: currentProfile.display_name },
      { type: 'input', name: 'username', message: 'Username (unique):', default: currentProfile.username },
      { type: 'input', name: 'phone', message: 'Phone number (unique):', default: currentProfile.phone }
    ]);

    const spinner = ora('Saving profile...').start();
    await upsertProfile({
      id: user.id,
      email: user.email,
      display_name: answers.displayName,
      username: answers.username,
      phone: answers.phone
    });
    spinner.succeed('Profile setup complete!');
  } catch (error) {
    console.error(chalk.red('Setup failed: ' + error.message));
  }
}
