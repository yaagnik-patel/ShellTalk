# ShellTalk CLI

Terminal-based messaging app for developers. Talk to your friends directly from the terminal!

## Install
\`\`\`bash
npm install -g shelltalk-cli
\`\`\`

## Setup Environment
Create a \`.env\` file or set the following environment variables:
\`\`\`bash
SUPABASE_URL=your_supabase_url
SUPABASE_ANON_KEY=your_supabase_anon_key
SHELLTALK_ENCRYPTION_KEY=your_32_character_secret_encryption_key
\`\`\`

## User Flow

### 1. Login
\`\`\`bash
shelltalk login
\`\`\`
Follow the link to login via Supabase OTP.

### 2. Setup Profile
\`\`\`bash
shelltalk setup
\`\`\`
Set your username, display name, and phone number. Your phone number is encrypted in the database.

### 3. Start Hacking / Chatting
\`\`\`bash
shelltalk
\`\`\`

## Commands Inside ShellTalk

* \`ls\` - List your accepted friends.
* \`add @username\` - Send a friend request. (Receiver must accept before chatting)
* \`requests\` - Show all incoming pending friend requests.
* \`accept @username\` - Accept an incoming friend request.
* \`reject @username\` - Reject an incoming friend request.
* \`pending\` - Show outgoing pending friend requests.
* \`cd @username\` - Enter a chat with a friend.
* \`cd ..\` - Exit current chat.
* \`block @username\` - Block a user from messaging or requesting you.
* \`unblock @username\` - Unblock a user.
* \`me\` - Show your current profile info.
* \`clear\` - Clear the terminal.
* \`exit\` - Exit ShellTalk.

## Privacy & Security
* **Friend Requests:** You must accept a friend request before anyone can message you.
* **Encryption:** Phone numbers and message bodies are encrypted before saving to the database using AES-256-GCM. Never store plain text messages.
* **Public Info:** Usernames are strictly public identity. 
* **Read Receipts:** Messages turn green when read by the other users.
