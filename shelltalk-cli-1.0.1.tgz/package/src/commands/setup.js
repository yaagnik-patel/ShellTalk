import inquirer from 'inquirer';
import ora from 'ora';
import chalk from 'chalk';
import { getUser } from '../services/authService.js';
import { getProfile, upsertProfile } from '../services/profileService.js';
import { encryptText, decryptText, hashText } from '../utils/crypto.js';

export async function setup() {
  try {
    const user = await getUser();
    if (!user) {
      console.log(chalk.red('Please login first using `shelltalk login`'));
      return;
    }

    const currentProfile = await getProfile(user.id) || {};
    
    let defaultPhone = '';
    if (currentProfile.phone_encrypted) {
      defaultPhone = decryptText(currentProfile.phone_encrypted);
    } else if (currentProfile.phone) {
      // Legacy transition fallback if needed
      defaultPhone = currentProfile.phone;
    }

    const answers = await inquirer.prompt([
      { type: 'input', name: 'displayName', message: 'Display Name:', default: currentProfile.display_name },
      { type: 'input', name: 'username', message: 'Username (unique):', default: currentProfile.username },
      { type: 'input', name: 'phone', message: 'Phone number (unique):', default: defaultPhone }
    ]);

    const spinner = ora('Saving profile...').start();
    
    const normalizedUsername = answers.username.toLowerCase().trim();
    const normalizedPhone = answers.phone.replace(/[\s\-\+]/g, '').trim();

    await upsertProfile({
      id: user.id,
      email: user.email,
      display_name: answers.displayName,
      username: normalizedUsername,
      phone_encrypted: encryptText(normalizedPhone),
      phone_hash: hashText(normalizedPhone)
    });
    
    spinner.succeed('Profile setup complete!');
  } catch (error) {
    console.error(chalk.red('Setup failed: ' + error.message));
  }
}
