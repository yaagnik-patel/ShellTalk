import boxen from 'boxen';
import chalk from 'chalk';
import { colors, symbols } from './colors.js';

export function renderWelcome() {
  const content = `${colors.primary('Welcome to ShellTalk!')}\n\n` +
    `Your terminal-based messaging app.\n` +
    `Type ${chalk.bold('ls')} to see friends, ${chalk.bold('cd @username')} to chat.`;
  
  console.log(boxen(content, {
    padding: 1,
    margin: 1,
    borderStyle: 'round',
    borderColor: 'green'
  }));
}

export function formatMessage(msg, isSender, senderUsername) {
  const time = new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  if (isSender) {
    let statusSymbol = symbols.sent;
    if (msg.status === 'delivered') statusSymbol = symbols.delivered;
    if (msg.status === 'read') statusSymbol = symbols.read;
    
    return `[${time}] ${colors.primary('You')}: ${msg.body} ${statusSymbol}`;
  } else {
    return `[${time}] ${colors.username('@' + senderUsername)}: ${msg.body}`;
  }
}
