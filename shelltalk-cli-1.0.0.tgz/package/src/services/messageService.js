import { supabase } from '../config/supabase.js';

export async function sendMessage(senderId, receiverId, body) {
  const { data, error } = await supabase
    .from('messages')
    .insert({ sender_id: senderId, receiver_id: receiverId, body, status: 'sent' })
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function getChatMessages(userId, friendId, limit = 50) {
  const { data, error } = await supabase
    .from('messages')
    .select('*')
    .or(`and(sender_id.eq.${userId},receiver_id.eq.${friendId}),and(sender_id.eq.${friendId},receiver_id.eq.${userId})`)
    .order('created_at', { ascending: true })
    .limit(limit);
  if (error) throw error;
  return data;
}

export async function markMessagesAsRead(senderId, receiverId) {
  const { error } = await supabase
    .from('messages')
    .update({ status: 'read', read_at: new Date().toISOString() })
    .eq('sender_id', senderId)
    .eq('receiver_id', receiverId)
    .neq('status', 'read');
  if (error) throw error;
}

export async function updateMessageStatus(messageId, status) {
  const { error } = await supabase
    .from('messages')
    .update({ status })
    .eq('id', messageId);
  if (error) throw error;
}
