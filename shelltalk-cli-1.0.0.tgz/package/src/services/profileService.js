import { supabase } from '../config/supabase.js';

export async function getProfile(userId) {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single();
  if (error && error.code !== 'PGRST116') throw error;
  return data;
}

export async function upsertProfile(profileData) {
  const { data, error } = await supabase
    .from('profiles')
    .upsert(profileData)
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function findProfileByUsernameOrPhone(identifier) {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .or(`username.eq.${identifier},phone.eq.${identifier}`)
    .single();
  if (error && error.code !== 'PGRST116') throw error;
  return data;
}
