import { createClient } from '@supabase/supabase-js';
import WebSocket from 'ws';
import { getSession, setSession } from './session.js';

// Fix for Node < 22 WebSocket support
globalThis.WebSocket = WebSocket;

// Hardcoded for global npm distribution so users don't need a .env file!
const supabaseUrl = 'https://fitzjlgakfqfaftirpjl.supabase.co';
const supabaseKey = 'sb_publishable_Ma7xJPxbyWKm4ZFKL8tfOQ_b87tX1ys';

export const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: {
    persistSession: false,
    autoRefreshToken: true,
  },
  global: {
    WebSocket,
  }
});

const localSession = getSession();
if (localSession) {
  try {
    await supabase.auth.setSession({
      access_token: localSession.access_token,
      refresh_token: localSession.refresh_token
    });
  } catch (err) {
    // Session might be expired
  }
}

supabase.auth.onAuthStateChange((event, session) => {
  if (session) {
    setSession(session);
  }
});
